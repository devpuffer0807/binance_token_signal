var mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
  e: {
    type: String,
  },
  E: {
    type: Number,
  },
  s: {
    type: String,
  },
  p: {
    type: String,
  },
  P: {
    type: String,
  },
  w: {
    type: String,
  },
  c: {
    type: String,
  },
  Q: {
    type: String,
  },
  b: {
    type: String,
  },
  B: {
    type: String,
  },
  a: {
    type: String,
  },
  A: {
    type: String,
  },
  o: {
    type: String,
  },
  h: {
    type: String,
  },
  l: {
    type: String,
  },
  v: {
    type: String,
  },
  q: {
    type: String,
  },
  O: {
    type: Number,
  },
  C: {
    type: Number,
  },
  F: {
    type: Number,
  },
  L: {
    type: Number,
  },
  n: {
    type: Number,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Transaction", transactionSchema);
