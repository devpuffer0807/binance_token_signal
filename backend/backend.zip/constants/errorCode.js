var errorCode = {
    unexpectedError: 0,
    smtpEmailError: 1,
};

module.exports = errorCode;