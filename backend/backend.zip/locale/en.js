var errorMessage = {
  emailError: "EMAIL_ERROR",
  unregisterEmail: "UNREGISTER_EMAIL",
  unexpectedError: "UNEXPECTED_ERROR",
  verificationCodeError: "VERIFICATION_CODE_ERROR",
};

module.exports = errorMessage;